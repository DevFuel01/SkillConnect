<?php include 'header.php'; ?>

<div class="auth-form">
    <h2 class="text-center" style="margin-bottom: 2rem;">Login</h2>
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>

    <form action="../backend/auth.php" method="POST">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%;">Login</button>
        <p class="text-center mt-4">Don't have an account? <a href="register.php">Sign up</a></p>
    </form>
</div>

<?php include 'footer.php'; ?>