<?php
require_once '../backend/db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch topics
$stmt = $pdo->query("
    SELECT t.id, t.title, t.created_at, u.name as author 
    FROM forum_topics t 
    JOIN users u ON t.user_id = u.id 
    ORDER BY t.created_at DESC
");
$topics = $stmt->fetchAll();
?>

<div class="container main-content">
    <div class="flex justify-between items-center" style="margin-bottom: 2rem;">
        <h1>Discussion Forum</h1>
        <button onclick="document.getElementById('newTopicModal').style.display='block'" class="btn btn-primary">
            <i class="fas fa-plus"></i> New Topic
        </button>
    </div>

    <!-- New Topic Modal (Simple inline implementation) -->
    <div id="newTopicModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000;">
        <div style="background:white; max-width:500px; margin: 100px auto; padding:20px; border-radius:8px;">
            <h3>Create New Topic</h3>
            <form action="../backend/forum_action.php" method="POST">
                <input type="hidden" name="action" value="create_topic">
                <div class="form-group">
                    <label>Topic Title</label>
                    <input type="text" name="title" required>
                </div>
                <!-- Optional: Initial post content can be added here -->
                <div class="form-group">
                    <label>First Post</label>
                    <textarea name="content" rows="4" required></textarea>
                </div>
                <div style="text-align: right;">
                    <button type="button" onclick="document.getElementById('newTopicModal').style.display='none'" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <?php if (empty($topics)): ?>
            <p>No topics yet. Be the first to post!</p>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #e2e8f0; text-align: left;">
                        <th style="padding: 10px;">Topic</th>
                        <th style="padding: 10px;">Author</th>
                        <th style="padding: 10px;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topics as $topic): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 15px 10px;">
                                <a href="topic.php?id=<?php echo $topic['id']; ?>" style="font-weight: 600; text-decoration: none; color: var(--primary-color);">
                                    <?php echo htmlspecialchars($topic['title']); ?>
                                </a>
                            </td>
                            <td style="padding: 15px 10px;"><?php echo htmlspecialchars($topic['author']); ?></td>
                            <td style="padding: 15px 10px;"><?php echo date('M j, Y', strtotime($topic['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>