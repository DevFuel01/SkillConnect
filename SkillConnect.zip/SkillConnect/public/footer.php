    </main>
    <footer>
        <div class="container text-center" style="padding: 20px 0; color: var(--secondary-color);">
            <p>&copy; <?php echo date('Y'); ?> SkillConnect. Connect, Collaborate, Create.</p>
        </div>
    </footer>
    <script src="js/main.js"></script>
    </body>

    </html>