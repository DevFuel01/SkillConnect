<?php
require_once '../backend/db.php';
require_once '../backend/functions.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $skills = trim($_POST['skills']);
    $interests = trim($_POST['interests']);
    $goals = trim($_POST['goals']);

    $stmt = $pdo->prepare("UPDATE users SET skills = ?, interests = ?, project_goals = ? WHERE id = ?");
    if ($stmt->execute([$skills, $interests, $goals, $_SESSION['user_id']])) {
        $message = "Profile updated successfully!";
    } else {
        $message = "Error updating profile.";
    }
}

$user = getUserProfile($pdo, $_SESSION['user_id']);
?>

<div class="container main-content">
    <div class="auth-form" style="max-width: 600px; margin-top: 0;">
        <h2>Edit Profile</h2>
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Skills (comma separated)</label>
                <input type="text" name="skills" value="<?php echo htmlspecialchars($user['skills'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Interests (comma separated)</label>
                <input type="text" name="interests" value="<?php echo htmlspecialchars($user['interests'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Project Goals</label>
                <textarea name="goals" rows="4"><?php echo htmlspecialchars($user['project_goals'] ?? ''); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>