<?php include 'header.php'; ?>

<div class="hero">
    <h1>Connect with Innovators</h1>
    <p>Find mentors, collaborators, and friends who share your passion.</p>
    <div style="margin-top: 2rem;">
        <a href="register.php" class="btn btn-primary" style="font-size: 1.2rem; padding: 1rem 2.5rem;">Get Started</a>
        <a href="login.php" class="btn btn-secondary" style="font-size: 1.2rem; padding: 1rem 2.5rem; margin-left: 10px;">Login</a>
    </div>
</div>

<div class="container" style="padding: 4rem 0;">
    <div class="dashboard-grid" style="grid-template-columns: repeat(3, 1fr);">
        <div class="card text-center">
            <h3><i class="fas fa-users"></i> Find Mentors</h3>
            <p>Connect with experienced professionals in your field.</p>
        </div>
        <div class="card text-center">
            <h3><i class="fas fa-project-diagram"></i> Collaborate</h3>
            <p>Find partners for your next big project.</p>
        </div>
        <div class="card text-center">
            <h3><i class="fas fa-comments"></i> Discuss</h3>
            <p>Join forum discussions on topics you love.</p>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>