<?php
require_once '../backend/db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$topicId = $_GET['id'] ?? 0;

// Fetch Topic Details
$stmt = $pdo->prepare("SELECT t.*, u.name as author FROM forum_topics t JOIN users u ON t.user_id = u.id WHERE t.id = ?");
$stmt->execute([$topicId]);
$topic = $stmt->fetch();

if (!$topic) {
    echo "<div class='container main-content'><p>Topic not found.</p></div>";
    include 'footer.php';
    exit;
}

// Fetch Posts
$stmt = $pdo->prepare("
    SELECT p.*, u.name as author 
    FROM forum_posts p 
    JOIN users u ON p.user_id = u.id 
    WHERE p.topic_id = ? 
    ORDER BY p.created_at ASC
");
$stmt->execute([$topicId]);
$posts = $stmt->fetchAll();
?>

<div class="container main-content">
    <div style="margin-bottom: 20px;">
        <a href="forum.php" class="btn btn-secondary">&larr; Back to Forum</a>
    </div>

    <div class="card" style="margin-bottom: 20px; background: #edeffc;">
        <h1><?php echo htmlspecialchars($topic['title']); ?></h1>
        <p style="font-size: 0.9rem; color: #64748b;">
            Started by <?php echo htmlspecialchars($topic['author']); ?> on <?php echo date('M j, Y H:i', strtotime($topic['created_at'])); ?>
        </p>
    </div>

    <div class="posts-list">
        <?php foreach ($posts as $post): ?>
            <div class="card" style="margin-bottom: 15px; border-left: 4px solid var(--primary-color);">
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <strong><?php echo htmlspecialchars($post['author']); ?></strong>
                    <span style="font-size: 0.8rem; color: #94a3b8;"><?php echo date('M j, Y H:i', strtotime($post['created_at'])); ?></span>
                </div>
                <div style="line-height: 1.6;">
                    <?php echo nl2br(htmlspecialchars($post['content'])); ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Reply Form -->
    <div class="card" style="margin-top: 30px;">
        <h3>Reply to this topic</h3>
        <form action="../backend/forum_action.php" method="POST">
            <input type="hidden" name="action" value="reply_topic">
            <input type="hidden" name="topic_id" value="<?php echo $topic['id']; ?>">
            <div class="form-group">
                <textarea name="content" rows="4" required placeholder="Write your reply here..." style="width: 100%; padding: 10px;"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Post Reply</button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>