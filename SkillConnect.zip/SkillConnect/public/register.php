<?php include 'header.php'; ?>

<div class="auth-form" style="max-width: 500px;">
    <h2 class="text-center" style="margin-bottom: 2rem;">Create Account</h2>
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>

    <form action="../backend/auth.php" method="POST">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="name" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required minlength="6">
        </div>
        <div class="form-group">
            <label>Skills (comma separated)</label>
            <input type="text" name="skills" placeholder="e.g. PHP, JavaScript, Design">
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
        <p class="text-center mt-4">Already have an account? <a href="login.php">Login</a></p>
    </form>
</div>

<?php include 'footer.php'; ?>