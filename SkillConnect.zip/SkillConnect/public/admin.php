<?php
require_once '../backend/db.php';
include 'header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins
    header("Location: dashboard.php");
    exit;
}

// Fetch stats
$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$topicCount = $pdo->query("SELECT COUNT(*) FROM forum_topics")->fetchColumn();
$msgCount = $pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();

// Fetch Users
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

// Fetch Recent Topics
$topics = $pdo->query("SELECT t.*, u.name as author FROM forum_topics t JOIN users u ON t.user_id = u.id ORDER BY created_at DESC LIMIT 10")->fetchAll();
?>

<div class="container main-content">
    <h1>Admin Dashboard</h1>

    <div class="admin-stats-grid" style="margin: 30px 0;">
        <div class="card text-center" style="background: #e0e7ff;">
            <h3><?php echo $userCount; ?></h3>
            <p>Total Users</p>
        </div>
        <div class="card text-center" style="background: #e0e7ff;">
            <h3><?php echo $topicCount; ?></h3>
            <p>Forum Topics</p>
        </div>
        <div class="card text-center" style="background: #e0e7ff;">
            <h3><?php echo $msgCount; ?></h3>
            <p>Total Messages</p>
        </div>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>

    <div class="card" style="margin-bottom: 30px;">
        <h3>All Users</h3>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
                <thead>
                    <tr style="background: #f8fafc; text-align: left;">
                        <th style="padding: 10px;">ID</th>
                        <th style="padding: 10px;">Name</th>
                        <th style="padding: 10px;">Email</th>
                        <th style="padding: 10px;">Role</th>
                        <th style="padding: 10px;">Skills</th>
                        <th style="padding: 10px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 10px;"><?php echo $user['id']; ?></td>
                            <td style="padding: 10px;"><?php echo htmlspecialchars($user['name']); ?></td>
                            <td style="padding: 10px;"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td style="padding: 10px;">
                                <span style="background: <?php echo $user['role'] === 'admin' ? '#dcfce7' : '#f1f5f9'; ?>; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem;">
                                    <?php echo $user['role']; ?>
                                </span>
                            </td>
                            <td style="padding: 10px; font-size: 0.9rem; color: #64748b;"><?php echo htmlspecialchars(substr($user['skills'] ?? '', 0, 30)) . '...'; ?></td>
                            <td style="padding: 10px;">
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <form action="../backend/admin_action.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this user? This cannot be undone.');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn" style="background: #fee2e2; color: #991b1b; padding: 0.4rem 0.8rem; font-size: 0.8rem;">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h3>Recent Forum Topics</h3>
        <ul style="list-style: none; margin-top: 15px;">
            <?php foreach ($topics as $topic): ?>
                <li style="border-bottom: 1px solid #f1f5f9; padding: 10px 0; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <a href="topic.php?id=<?php echo $topic['id']; ?>" style="font-weight: 500; text-decoration: none; color: #4f46e5;">
                            <?php echo htmlspecialchars($topic['title']); ?>
                        </a>
                        <span style="color: #94a3b8; font-size: 0.9rem; margin-left: 10px;">by <?php echo htmlspecialchars($topic['author']); ?></span>
                    </div>
                    <form action="../backend/admin_action.php" method="POST" onsubmit="return confirm('Delete this topic and all its posts?');">
                        <input type="hidden" name="action" value="delete_topic">
                        <input type="hidden" name="topic_id" value="<?php echo $topic['id']; ?>">
                        <button type="submit" class="btn" style="background: #fee2e2; color: #991b1b; padding: 0.3rem 0.6rem; font-size: 0.8rem;">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<?php include 'footer.php'; ?>