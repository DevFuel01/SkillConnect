<?php
require_once '../backend/db.php';
require_once '../backend/functions.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$activeUserId = $_GET['compose'] ?? 0;
// If compose is set, we start a chat with that user.
if ($activeUserId) {
    $stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->execute([$activeUserId]);
    $activeUserName = $stmt->fetchColumn();
} else {
    $activeUserName = '';
}
?>

<div class="container main-content">
    <div class="dashboard-grid" style="height: calc(100vh - 180px); gap: 0; box-shadow: var(--shadow); border-radius: 8px; overflow: hidden; background: white;">

        <!-- Sidebar: Conversation List -->
        <div class="sidebar" style="border-radius: 0; border-right: 1px solid #e2e8f0; height: 100%; overflow-y: auto; padding: 0;">
            <div style="padding: 15px; border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
                <h3 style="margin: 0; font-size: 1.1rem;">Messages</h3>
            </div>
            <div id="conversation-list">
                <!-- Loaded via AJAX -->
                <p style="padding: 20px; text-align: center; color: #94a3b8;">Loading contacts...</p>
            </div>
        </div>

        <!-- Main Chat Area -->
        <div style="display: flex; flex-direction: column; height: 100%;">

            <!-- Chat Header -->
            <div style="padding: 15px; border-bottom: 1px solid #e2e8f0; background: #fff;">
                <h3 id="chat-header-name" style="margin: 0;"><?php echo $activeUserName ? htmlspecialchars($activeUserName) : 'Select a conversation'; ?></h3>
            </div>

            <!-- Messages Container -->
            <div id="chat-messages" style="flex: 1; overflow-y: auto; padding: 20px; background: #f1f5f9; display: flex; flex-direction: column; gap: 10px;">
                <?php if (!$activeUserId): ?>
                    <div style="text-align: center; margin-top: 50px; color: #64748b;">
                        <i class="fas fa-paper-plane" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
                        <p>Select a user to start messaging</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Input Area -->
            <div style="padding: 15px; border-top: 1px solid #e2e8f0; background: #fff; <?php echo !$activeUserId ? 'display:none;' : ''; ?>" id="chat-input-area">
                <form id="message-form" style="display: flex; gap: 10px;">
                    <input type="hidden" id="receiver_id" value="<?php echo htmlspecialchars($activeUserId); ?>">
                    <input type="text" id="message-text" placeholder="Type a message..." style="flex: 1; padding: 10px; border: 1px solid #cbd5e1; border-radius: 4px;" required autocomplete="off">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                </form>
            </div>

        </div>
    </div>
</div>

<script>
    // Messaging Logic
    const currentUserId = <?php echo $_SESSION['user_id']; ?>;
    let activeReceiverId = <?php echo $activeUserId ?: 'null'; ?>;

    // Elements
    const conversationListEl = document.getElementById('conversation-list');
    const chatMessagesEl = document.getElementById('chat-messages');
    const chatHeaderNameEl = document.getElementById('chat-header-name');
    const chatInputAreaEl = document.getElementById('chat-input-area');
    const messageForm = document.getElementById('message-form');
    const receiverIdInput = document.getElementById('receiver_id');

    // Fetch Conversations List
    function loadConversations() {
        fetch('../backend/messages.php?action=list_conversations')
            .then(res => res.json())
            .then(data => {
                conversationListEl.innerHTML = '';
                if (data.length === 0) {
                    conversationListEl.innerHTML = '<p style="padding:15px; color:#64748b;">No conversations yet.</p>';
                }
                data.forEach(user => {
                    const div = document.createElement('div');
                    div.style.padding = '15px';
                    div.style.borderBottom = '1px solid #f1f5f9';
                    div.style.cursor = 'pointer';
                    div.style.background = (user.id == activeReceiverId) ? '#f1f5f9' : 'transparent';
                    div.innerHTML = `<strong>${user.name}</strong>`;
                    div.onclick = () => loadChat(user.id, user.name);
                    conversationListEl.appendChild(div);
                });
            });
    }

    // Load Chat with specific user
    function loadChat(userId, userName) {
        activeReceiverId = userId;
        receiverIdInput.value = userId;
        chatHeaderNameEl.textContent = userName;
        chatInputAreaEl.style.display = 'block';
        chatMessagesEl.innerHTML = 'Loading...';

        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('compose', userId);
        window.history.pushState({}, '', url);

        loadConversations(); // Refresh list to update selection highlight
        fetchMessages();
    }

    // Fetch Messages for active chat
    function fetchMessages() {
        if (!activeReceiverId) return;

        fetch(`../backend/messages.php?action=get_messages&user_id=${activeReceiverId}`)
            .then(res => res.json())
            .then(data => {
                chatMessagesEl.innerHTML = '';
                if (data.length === 0) {
                    chatMessagesEl.innerHTML = '<p style="text-align:center; color:#94a3b8; margin-top:20px;">No messages yet. Say hi!</p>';
                }
                data.forEach(msg => {
                    const isMe = msg.sender_id == currentUserId;
                    const div = document.createElement('div');
                    div.style.maxWidth = '70%';
                    div.style.padding = '10px 15px';
                    div.style.borderRadius = '15px';
                    div.style.fontSize = '0.9rem';
                    div.style.alignSelf = isMe ? 'flex-end' : 'flex-start';
                    div.style.background = isMe ? 'var(--primary-color)' : 'white';
                    div.style.color = isMe ? 'white' : '#333';
                    div.style.boxShadow = '0 1px 2px rgba(0,0,0,0.1)';

                    div.textContent = msg.message;
                    chatMessagesEl.appendChild(div);
                });
                chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
            });
    }

    // Send Message
    messageForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = document.getElementById('message-text').value;

        fetch('../backend/messages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `action=send&receiver_id=${activeReceiverId}&message=${encodeURIComponent(text)}`
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('message-text').value = '';
                    fetchMessages();
                }
            });
    });

    // Initial Load
    loadConversations();
    if (activeReceiverId) {
        fetchMessages();
        setInterval(fetchMessages, 3000); // Poll every 3s
    }
</script>

<?php include 'footer.php'; ?>