<?php
require_once '../backend/db.php';
require_once '../backend/functions.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$matches = getMatchingUsers($pdo, $_SESSION['user_id']);
?>

<div class="container main-content">
    <div class="dashboard-grid">
        <aside class="sidebar">
            <h3>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h3>
            <ul style="list-style: none; margin-top: 1rem;">
                <li style="margin-bottom: 0.5rem;"><a href="profile.php" class="btn btn-secondary" style="width: 100%; text-align: left;"><i class="fas fa-user-edit"></i> Edit Profile</a></li>
                <li style="margin-bottom: 0.5rem;"><a href="messages.php" class="btn btn-secondary" style="width: 100%; text-align: left;"><i class="fas fa-envelope"></i> Messages</a></li>
                <li style="margin-bottom: 0.5rem;"><a href="forum.php" class="btn btn-secondary" style="width: 100%; text-align: left;"><i class="fas fa-comments"></i> Forum</a></li>
            </ul>
        </aside>

        <section>
            <div class="card">
                <h2>Suggested Connections</h2>
                <p>Based on your skills and interests</p>

                <?php if (empty($matches)): ?>
                    <p class="mt-4">No recommendations yet. update your profile skills to get better matches!</p>
                <?php else: ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; margin-top: 20px;">
                        <?php foreach ($matches as $match): ?>
                            <div style="border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px;">
                                <h4 style="margin-bottom: 5px;"><?php echo htmlspecialchars($match['name']); ?></h4>
                                <p style="font-size: 0.9rem; color: #64748b; margin-bottom: 10px;">
                                    <strong>Skills:</strong> <?php echo htmlspecialchars($match['skills']); ?>
                                </p>
                                <p style="font-size: 0.8rem; color: #4f46e5; margin-bottom: 15px;">
                                    Match Score: <?php echo $match['match_score']; ?>
                                </p>
                                <a href="messages.php?compose=<?php echo $match['id']; ?>" class="btn btn-primary" style="font-size: 0.9rem;">Connect</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>

<?php include 'footer.php'; ?>