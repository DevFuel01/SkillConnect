<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$currentUserId = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'list_conversations') {
        // Find users I have exchanged messages with, OR return compose user if no messages yet logic could be complex. 
        // Simpler: Just get distinct users from messages
        $sql = "
            SELECT DISTINCT u.id, u.name 
            FROM users u
            JOIN messages m ON (m.sender_id = u.id AND m.receiver_id = ?) 
                            OR (m.receiver_id = u.id AND m.sender_id = ?)
            WHERE u.id != ?
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$currentUserId, $currentUserId, $currentUserId]);
        $users = $stmt->fetchAll();

        echo json_encode($users);
    } elseif ($action === 'get_messages') {
        $otherUserId = $_GET['user_id'] ?? 0;
        $stmt = $pdo->prepare("
            SELECT * FROM messages 
            WHERE (sender_id = ? AND receiver_id = ?) 
               OR (sender_id = ? AND receiver_id = ?) 
            ORDER BY created_at ASC
        ");
        $stmt->execute([$currentUserId, $otherUserId, $otherUserId, $currentUserId]);
        $messages = $stmt->fetchAll();
        echo json_encode($messages);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'send') {
        $receiverId = $_POST['receiver_id'];
        $message = $_POST['message'];

        if (!empty($receiverId) && !empty($message)) {
            $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$currentUserId, $receiverId, $message]);
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Empty fields']);
        }
    }
}
