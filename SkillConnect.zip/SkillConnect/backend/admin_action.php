<?php
session_start();
require_once 'db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../public/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete_user') {
        $userId = $_POST['user_id'] ?? 0;

        // Prevent admin from deleting themselves
        if ($userId == $_SESSION['user_id']) {
            header("Location: ../public/admin.php?error=You cannot delete yourself.");
            exit;
        }

        if ($userId) {
            // Delete user statements (Cascading deletion handles related data if configured in DB, 
            // but explicitly: users table delete will trigger ON DELETE CASCADE for foreign keys)
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            if ($stmt->execute([$userId])) {
                header("Location: ../public/admin.php?success=User deleted successfully.");
                exit;
            } else {
                header("Location: ../public/admin.php?error=Failed to delete user.");
                exit;
            }
        }
    } elseif ($action === 'delete_topic') {
        $topicId = $_POST['topic_id'] ?? 0;

        if ($topicId) {
            // Delete topic (ON DELETE CASCADE will match posts)
            $stmt = $pdo->prepare("DELETE FROM forum_topics WHERE id = ?");
            if ($stmt->execute([$topicId])) {
                header("Location: ../public/admin.php?success=Topic deleted successfully.");
                exit;
            } else {
                header("Location: ../public/admin.php?error=Failed to delete topic.");
                exit;
            }
        }
    }
}

// Fallback
header("Location: ../public/admin.php");
exit;
