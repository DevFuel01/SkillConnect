<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = $_SESSION['user_id'];

    if ($action === 'create_topic') {
        $title = trim($_POST['title']);
        $content = trim($_POST['content']);

        if (!empty($title)) {
            // Create Topic
            $stmt = $pdo->prepare("INSERT INTO forum_topics (title, user_id) VALUES (?, ?)");
            $stmt->execute([$title, $userId]);
            $topicId = $pdo->lastInsertId();

            // Create First Post
            if (!empty($content)) {
                $stmt = $pdo->prepare("INSERT INTO forum_posts (topic_id, user_id, content) VALUES (?, ?, ?)");
                $stmt->execute([$topicId, $userId, $content]);
            }

            header("Location: ../public/topic.php?id=$topicId");
            exit;
        }
    } elseif ($action === 'reply_topic') {
        $topicId = $_POST['topic_id'];
        $content = trim($_POST['content']);

        if (!empty($content) && !empty($topicId)) {
            $stmt = $pdo->prepare("INSERT INTO forum_posts (topic_id, user_id, content) VALUES (?, ?, ?)");
            $stmt->execute([$topicId, $userId, $content]);
            header("Location: ../public/topic.php?id=$topicId");
            exit;
        }
    }
}

// Fallback
header("Location: ../public/forum.php");
exit;
