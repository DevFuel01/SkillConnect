<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $skills = trim($_POST['skills']);

        // Basic validation
        if (empty($name) || empty($email) || empty($password)) {
            header("Location: ../public/register.php?error=All fields are required");
            exit;
        }

        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            header("Location: ../public/register.php?error=Email already exists");
            exit;
        }

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, skills, role) VALUES (?, ?, ?, ?, 'user')");
        if ($stmt->execute([$name, $email, $hashed_password, $skills])) {
            header("Location: ../public/login.php?success=Registration successful! Please login.");
            exit;
        } else {
            header("Location: ../public/register.php?error=Registration failed");
            exit;
        }
    } elseif ($action === 'login') {
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            header("Location: ../public/dashboard.php");
            exit;
        } else {
            header("Location: ../public/login.php?error=Invalid email or password");
            exit;
        }
    }
}
