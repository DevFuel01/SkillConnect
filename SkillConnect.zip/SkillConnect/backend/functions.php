<?php
require_once 'db.php';

function getMatchingUsers($pdo, $userId)
{
    // 1. Get current user's skills and interests
    $stmt = $pdo->prepare("SELECT skills, interests FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $currentUser = $stmt->fetch();

    if (!$currentUser) return [];

    $mySkills = array_map('trim', explode(',', strtolower($currentUser['skills'] ?? '')));
    $myInterests = array_map('trim', explode(',', strtolower($currentUser['interests'] ?? '')));

    // 2. Fetch other users
    $stmt = $pdo->prepare("SELECT id, name, skills, interests, project_goals FROM users WHERE id != ? AND role != 'admin'");
    $stmt->execute([$userId]);
    $allUsers = $stmt->fetchAll();

    $matches = [];

    foreach ($allUsers as $user) {
        $userSkills = array_map('trim', explode(',', strtolower($user['skills'] ?? '')));
        $userInterests = array_map('trim', explode(',', strtolower($user['interests'] ?? '')));

        // Calculate overlap
        $skillOverlap = array_intersect($mySkills, $userSkills);
        $interestOverlap = array_intersect($myInterests, $userInterests);
        $score = count($skillOverlap) + count($interestOverlap);

        if ($score > 0) {
            $user['match_score'] = $score;
            $user['shared_skills'] = implode(', ', array_intersect($mySkills, $userSkills)); // Show what matches
            $matches[] = $user;
        }
    }

    // Sort by match score descending
    usort($matches, function ($a, $b) {
        return $b['match_score'] - $a['match_score'];
    });

    return $matches;
}

function getUserProfile($pdo, $userId)
{
    $stmt = $pdo->prepare("SELECT name, email, skills, interests, project_goals FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}
