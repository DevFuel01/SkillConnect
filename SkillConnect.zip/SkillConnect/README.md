# SkillConnect

SkillConnect is a full-stack student and innovator networking platform. It connects users based on skills and interests, facilitates discussions via forums, and enables real-time collaboration through private messaging.

## Features
- **User Authentication**: Secure Login/Register with password hashing.
- **Smart Matching**: Recommendation algorithm connects users with similar skills/interests.
- **Discussion Forum**: Create topics, reply to threads.
- **Real-time Messaging**: AJAX-powered private chat system.
- **Admin Dashboard**: Overview of platform stats and users.
- **Responsive UI**: Modern, clean interface that works on mobile and desktop.

## Tech Stack
- **Frontend**: HTML, CSS, JavaScript
- **Backend**: PHP (PDO)
- **Database**: MySQL

## Setup Instructions

### 1. Requirements
- XAMPP (or any PHP/MySQL environment)

### 2. Installation
1. Clone or download this repository into your `htdocs` folder (e.g., `C:\xampp\htdocs\SkillConnect`).
2. Start **Apache** and **MySQL** in XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Create a new database named `skillconnect`.
5. Import `database/database.sql` into the `skillconnect` database.

### 3. Usage
1. Open your browser and go to `http://localhost/SkillConnect/public/`.
2. Register a new account.
3. Explore the dashboard, edit your profile, and start connecting!

### Default Admin Account
- **Email**: `admin@skillconnect.com`
- **Password**: `password123`

## Directory Structure
- `public/`: Contains all user-facing pages (index.php, dashboard.php, etc.) and assets.
- `backend/`: PHP logic files (auth.php, functions.php, messages.php).
- `database/`: SQL setup script.
- `docs/`: Documentation.

## Credits
Built for the Advanced Web Development Project.
